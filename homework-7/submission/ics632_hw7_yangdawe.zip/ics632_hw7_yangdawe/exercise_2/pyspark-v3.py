#!/usr/bin/env python3

import sys
import math
import random
import os
import time

from pyspark import SparkContext
from pyspark import SparkConf



#
# process() function
###
def process(work_unit):

    try:
        amount_of_work = int(work_unit[1])
    except ValueError:
        print("Invalid work unit spec '" + str(work_unit) + "'")
        sys.exit(1)

    # This is some fake computation that's configured for the purpose
    # of this assignment - pretend it's some useful ML training thingy :)
    y = 0.0
    for x in range(0, amount_of_work * amount_of_work):
        y += math.cos(math.sin(math.tan(x * x * x + random.randint(0,10))))

    return y


def loadBalancing(el, loadWorks):
    for i in range(len(loadWorks)):
        if el in loadWorks[i]:
            return (i, el[0])


#
# dowork() function
###
def dowork(sc, filename, number_of_partitions):
    number_of_partitions = int(number_of_partitions)
    rdd = sc.textFile("./"+filename, minPartitions = number_of_partitions)
    rdd = rdd.repartition(number_of_partitions)

    # Balancing
    rdd = rdd.sortBy(lambda x: -int(x)).zipWithIndex()
    temp = rdd.collect()   
    workLoads = []
    workLoadsCount = []

    for i in range(number_of_partitions):
        workLoadsCount.append(0)
        workLoads.append([])  

    for element in temp:
        min_index = workLoadsCount.index(min(workLoadsCount))
        workLoads[min_index].append(element)
        workLoadsCount[min_index] += int(element[0])   

    rdd = rdd.map(lambda x: loadBalancing(x, workLoads))
    rdd = rdd.partitionBy(number_of_partitions)

    print("Partitions structure: {}".format(rdd.glom().collect()))

    start = time.time()
    rdd = rdd.map(lambda x: process(x))
    counts = rdd.reduce(lambda a, b: a + b)
    end = time.time()
    print("total: {}".format(counts))
    print("Time elapsed: {}s".format(end-start))
    print("workload: {}".format(workLoadsCount))

    return

#
# main() function
###
def main():

    # Parse command-line arguments
    if len(sys.argv) != 3:
        sys.stderr.write("Usage: " + sys.argv[0] + " <input file> <number of partitions>\n")
        sys.exit(1)

    # Configure and instantiate a Spark context
    conf = SparkConf()
    conf.setMaster('spark://spark-master:7077')
    conf.setAppName('ICS632Homework')
    sc = SparkContext(conf=conf)

    # Seed the RNG
    random.seed(42)

    # Call the dowork() function]
    dowork(sc, sys.argv[1], sys.argv[2])


if __name__ == "__main__":
    main()


