#!/usr/bin/env python3

import os
import sys
import math
import random

from pyspark import SparkContext
from pyspark import SparkConf

from time import time

#
# process() function
###
def process(work_unit):

    try:
        amount_of_work = int(work_unit)
    except ValueError:
        print("Invalid work unit spec '" + str(work_unit) + "'")
        sys.exit(1)

    # This is some fake computation that's configured for the purpose
    # of this assignment - pretend it's some useful ML training thingy :)
    y = 0.0
    for x in range(0, amount_of_work * amount_of_work):
        y += math.cos(math.sin(math.tan(x * x * x + random.randint(0,10))))

    return y


#
# dowork() function
###
def dowork(sc, filename, n_partitions):

    # asking for at least 4 partitions
    rdd = sc.textFile(os.getcwd() + "/" + filename, minPartitions=4)

    # Repartitioning to enforce 4 partitions
    rdd = rdd.repartition(n_partitions)
    # print("Partitions structure: {}".format(rdd.glom().collect()))

    # map process()
    start = time()
    rdd = rdd.map(lambda x: process(x.rstrip()))

    # reduce
    s = rdd.reduce(lambda a,b : a + b)
    end = time()
    print(f"The sum of all values: {s}\n")
    print("The execution time: {:.2f} sec".format(end - start))

    return


#
# main() function
###
def main():

    # Parse command-line arguments
    if len(sys.argv) != 3:
        sys.stderr.write("Usage: " + sys.argv[0] + " <input file> <num partitions>\n")
        sys.exit(1)

    # Configure and instantiate a Spark context
    conf = SparkConf()
    conf.setMaster('spark://spark-master:7077')
    conf.setAppName('ICS632Homework')
    sc = SparkContext(conf=conf)

    # Seed the RNG
    random.seed(42)

    # Call the dowork() function
    dowork(sc, sys.argv[1], int(sys.argv[2]))

    sys.exit(0)


if __name__ == "__main__":
    main()

